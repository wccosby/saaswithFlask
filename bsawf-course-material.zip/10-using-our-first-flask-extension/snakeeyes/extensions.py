from flask_debugtoolbar import DebugToolbarExtension


debug_toolbar = DebugToolbarExtension()
